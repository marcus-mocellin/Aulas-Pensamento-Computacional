let xCar = [500, 500, 500, 500, 500, 500];
let yCar = [40, 96, 150, 210, 264, 318];
let velCar = [2, 2.5, 3.2, 5, 3.3, 1.6];
let comprCar = 50;
let largCar = 40;

function mostraCarro() {
  for (let i = 0; i < imagemCarros.length; i++) {
    image(imagemCarros[i], xCar[i], yCar[i], comprCar, largCar);
  }
}

function movimentaCarro() {
  for (let i = 0; i < xCar.length; i++) {
    xCar[i] -= velCar[i];
  }
}

function retornaCarro() {
  for (let i = 0; i < xCar.length; i++) {
    if (saiDaTela(xCar[i])) {
      xCar[i] = 500;
    }
  }
}

function saiDaTela(xCar) {
  return xCar < -50;
}
