let xAtor = 100;
let yAtor = 366;
let velAtor = 3;
let colisao = false;
let pontos = 0;

function mostraAtor() {
  image(imagemAtor, xAtor, yAtor, 30, 30);
}

function movimentaAtor() {
  if (keyIsDown(UP_ARROW)) {
    yAtor -= velAtor;
  }
  if (keyIsDown(DOWN_ARROW)) {
    if (verificayAtor()) {
      yAtor += velAtor;
    }
  }
}

function verificaColisaoCar() {
  for (let i = 0; i < imagemCarros.length; i++) {
    colisao = collideRectCircle(
      xCar[i],
      yCar[i],
      comprCar,
      largCar,
      xAtor,
      yAtor,
      15
    );
    if (colisao) {
      retornaAtor();
      somColisao.play();
      if (verificaPontos()) {
        pontos--;
      }
    }
  }
}

function mostraPontos() {
  textAlign(CENTER);
  textSize(25);
  fill(255, 240, 0);
  text(pontos, width / 2, 27);
}

function marcaPontos() {
  if (yAtor < 3) {
    pontos++;
    somPontos.play();
    retornaAtor();
  }
}

function retornaAtor() {
  yAtor = 366;
}

function verificaPontos() {
  return pontos > 0;
}

function verificayAtor() {
  return yAtor < 366;
}
