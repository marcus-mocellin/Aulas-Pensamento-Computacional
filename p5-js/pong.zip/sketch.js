let posxBola = 300;
let posyBola = 200;
let raioBola = 5;
let velocxBola = 3;
let velocyBola = 3;
let posxRaq = 5;
let posyRaq = 160;
let velocyRaq = 3;
let posxOpon = 585;
let posyOpon = 160;
let velocyOpon = 3;
let amarelo = 0;
let vermelho = 0;
let raquetada;
let ponto;
let trilha;

function setup() {
  createCanvas(600, 400);
  //trilha.play();
  trilha.loop();
}

function draw() {
  background(40, 110, 40);
  desenhaQuadra();
  desenhaRaquetes(posxRaq, posyRaq, 220, 230, 0);
  desenhaRaquetes(posxOpon, posyOpon, 230, 0, 0);
  controlaRaquetes();
  desenhaBolinha();
  movimentaBolinha();
  colisaoBordas();
  colisaoRaquetes();
  desenhaPlacar();
  atualizaPlacar();
}

function preload() {
    trilha = loadSound("trilha.mp3");
    ponto = loadSound("ponto.mp3");
    raquetada = loadSound("raquetada.mp3");
}
function desenhaQuadra() {  
  stroke(255, 255, 255);
  line(300, 0, 300, 400);
  fill(40, 110, 40);
  circle(300, 200, 50);
}

function desenhaRaquetes(x, y, R, G, B) {
  stroke(0, 0, 0);
  fill(R, G, B);
  rect(x, y, 10, 80);
}

function controlaRaquetes() {
  if (keyIsDown(65)) { // 65 = tecla A
    posyRaq -= 5;
  }
  if (keyIsDown(90)) { // 90 = tecla Z
    posyRaq += 5;
  }
  if (keyIsDown(UP_ARROW)) { // UP_ARROW = tecla seta para cima
    posyOpon -= 5;
  }
  if (keyIsDown(DOWN_ARROW)) { // DOWN_ARROW = tecla seta para baixo
    posyOpon += 5;
  }
}

function desenhaBolinha() {
  fill(255, 255, 255);
  circle(posxBola, posyBola, raioBola * 2);
}

function movimentaBolinha() {
  posxBola += velocxBola;
  posyBola += velocyBola;
}

function colisaoBordas() {
  if (posxBola + raioBola > width || posxBola < raioBola) {
    velocxBola *= -1;
  }
  if (posyBola + raioBola > height || posyBola < raioBola) {
    velocyBola *= -1;
  }
}

function colisaoRaquetes() {
  if (
    posxBola - raioBola < posxRaq + 10 &&
    posyBola < posyRaq + 80 &&
    posyBola > posyRaq
  ) {
    velocxBola *= -1;
    raquetada.play();
  }
  if (
    posxBola + raioBola > posxOpon &&
    posyBola < posyOpon + 80 &&
    posyBola > posyOpon
  ) {
    velocxBola *= -1;
    raquetada.play();
  }
}

function desenhaPlacar(){
  stroke(255);
  fill(255, 140, 0);
  rect(180, 10, 40, 20);
  rect(380, 10, 40, 20);
  textAlign(CENTER);
  textSize(16);
  fill(255);
  text(amarelo, 200, 26);
  text(vermelho, 400, 26);
}

function atualizaPlacar() {
  if (posxBola < 5) {
    vermelho += 1;
    ponto.play();
  }
  if (posxBola > 595) {
    amarelo += 1;
    ponto.play();
  }
}